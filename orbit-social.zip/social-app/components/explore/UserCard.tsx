import Link from "next/link";
import Image from "next/image";
import { initials } from "@/lib/utils";
import type { Profile } from "@/lib/types";

export function UserCard({ profile }: { profile: Profile }) {
  return (
    <div className="flex flex-col gap-4 rounded-xl2 border border-base-200 bg-white p-5 transition-shadow hover:shadow-[0_2px_12px_rgba(16,16,20,0.06)] dark:border-base-800 dark:bg-base-900">
      <div className="flex items-center gap-3">
        <div className="h-12 w-12 shrink-0 overflow-hidden rounded-full">
          {profile.avatar_url ? (
            <Image
              src={profile.avatar_url}
              alt={profile.display_name}
              width={48}
              height={48}
              className="h-full w-full object-cover"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center bg-signal-500 text-sm font-semibold text-white">
              {initials(profile.display_name || profile.username)}
            </div>
          )}
        </div>
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold">{profile.display_name || profile.username}</p>
          <p className="truncate text-sm text-base-900/45 dark:text-base-100/45">@{profile.username}</p>
        </div>
      </div>

      <p className="line-clamp-2 min-h-[2.5rem] text-sm text-base-900/70 dark:text-base-100/70">
        {profile.bio || "No bio yet."}
      </p>

      <Link
        href={`/profile/${profile.username}`}
        className="rounded-full border border-base-200 py-2 text-center text-sm font-medium transition-colors hover:bg-base-50 dark:border-base-800 dark:hover:bg-base-800"
      >
        View profile
      </Link>
    </div>
  );
}
