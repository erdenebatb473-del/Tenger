"use client";

import { Search, X } from "lucide-react";

export function SearchBar({
  value,
  onChange,
}: {
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <div className="relative">
      <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-base-900/35 dark:text-base-100/35" />
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Search by name or username"
        className="w-full rounded-full border border-base-200 bg-white py-3 pl-11 pr-11 text-sm outline-none transition-shadow focus:ring-2 focus:ring-signal-500 dark:border-base-800 dark:bg-base-900"
      />
      {value && (
        <button
          onClick={() => onChange("")}
          aria-label="Clear search"
          className="absolute right-3.5 top-1/2 flex h-5 w-5 -translate-y-1/2 items-center justify-center rounded-full bg-base-100 text-base-900/50 dark:bg-base-800 dark:text-base-100/50"
        >
          <X className="h-3 w-3" />
        </button>
      )}
    </div>
  );
}
