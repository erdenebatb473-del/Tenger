import { forwardRef } from "react";
import { cn } from "@/lib/utils";

type Variant = "primary" | "secondary" | "ghost" | "danger";

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  loading?: boolean;
}

const variants: Record<Variant, string> = {
  primary: "bg-signal-500 text-white hover:bg-signal-600 disabled:hover:bg-signal-500",
  secondary:
    "border border-base-200 bg-white text-base-900 hover:bg-base-50 dark:border-base-800 dark:bg-base-900 dark:text-base-100 dark:hover:bg-base-800",
  ghost: "text-base-900/70 hover:bg-base-100 dark:text-base-100/70 dark:hover:bg-base-800",
  danger: "bg-red-500/10 text-red-600 hover:bg-red-500/15 dark:text-red-400",
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "primary", loading, disabled, children, ...props }, ref) => {
    return (
      <button
        ref={ref}
        disabled={disabled || loading}
        className={cn(
          "inline-flex items-center justify-center gap-2 rounded-full px-5 py-2.5 text-sm font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-60",
          variants[variant],
          className
        )}
        {...props}
      >
        {loading && (
          <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-current/30 border-t-current" />
        )}
        {children}
      </button>
    );
  }
);
Button.displayName = "Button";
