"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { LogOut, Pencil } from "lucide-react";
import { toast } from "sonner";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/Button";

export function SettingsActions({ username }: { username: string }) {
  const router = useRouter();

  async function handleLogout() {
    const supabase = createClient();
    const { error } = await supabase.auth.signOut();
    if (error) {
      toast.error("Couldn't log out. Please try again.");
      return;
    }
    router.push("/login");
    router.refresh();
  }

  return (
    <div className="animate-fade-in space-y-3">
      <Link
        href={`/profile/${username}`}
        className="flex items-center justify-between rounded-xl2 border border-base-200 bg-white px-5 py-4 text-sm font-medium transition-colors hover:bg-base-50 dark:border-base-800 dark:bg-base-900 dark:hover:bg-base-800"
      >
        <span className="flex items-center gap-2">
          <Pencil className="h-4 w-4 text-base-900/50 dark:text-base-100/50" />
          Edit your profile
        </span>
        <span className="text-base-900/30 dark:text-base-100/30">→</span>
      </Link>

      <Button variant="danger" className="w-full" onClick={handleLogout}>
        <LogOut className="h-4 w-4" />
        Log out
      </Button>
    </div>
  );
}
