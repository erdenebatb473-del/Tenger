"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { Pencil } from "lucide-react";
import { initials } from "@/lib/utils";
import { Button } from "@/components/ui/Button";
import { EditProfileModal } from "@/components/profile/EditProfileModal";
import type { Profile } from "@/lib/types";

export function ProfileCard({ initialProfile }: { initialProfile: Profile }) {
  const [profile, setProfile] = useState(initialProfile);
  const [editing, setEditing] = useState(false);
  const router = useRouter();

  function handleSaved(updated: Profile) {
    setProfile(updated);
    setEditing(false);
    router.refresh();
  }

  return (
    <div className="animate-fade-in rounded-xl2 border border-base-200 bg-white p-5 dark:border-base-800 dark:bg-base-900">
      <div className="flex items-center gap-4">
        <Link href={`/profile/${profile.username}`} className="shrink-0">
          {profile.avatar_url ? (
            <Image
              src={profile.avatar_url}
              alt={profile.display_name}
              width={56}
              height={56}
              className="h-14 w-14 rounded-full object-cover"
            />
          ) : (
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-signal-500 text-lg font-semibold text-white">
              {initials(profile.display_name || profile.username)}
            </div>
          )}
        </Link>
        <div className="min-w-0 flex-1">
          <Link href={`/profile/${profile.username}`} className="block truncate font-semibold hover:underline">
            {profile.display_name || profile.username}
          </Link>
          <p className="truncate text-sm text-base-900/45 dark:text-base-100/45">@{profile.username}</p>
        </div>
        <Button variant="secondary" onClick={() => setEditing(true)} className="!px-4">
          <Pencil className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">Edit profile</span>
        </Button>
      </div>

      <p className="mt-4 line-clamp-2 text-sm text-base-900/70 dark:text-base-100/70">
        {profile.bio || "You haven't added a bio yet — tell people who you are."}
      </p>

      <EditProfileModal
        profile={profile}
        open={editing}
        onClose={() => setEditing(false)}
        onSaved={handleSaved}
      />
    </div>
  );
}
