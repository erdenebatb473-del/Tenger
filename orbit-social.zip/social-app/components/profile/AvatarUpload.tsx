"use client";

import { useRef } from "react";
import Image from "next/image";
import { Camera } from "lucide-react";
import { toast } from "sonner";
import { validateImageFile, initials } from "@/lib/utils";

interface AvatarUploadProps {
  previewUrl: string | null;
  fallbackName: string;
  onSelect: (file: File, previewUrl: string) => void;
  uploading?: boolean;
}

export function AvatarUpload({ previewUrl, fallbackName, onSelect, uploading }: AvatarUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null);

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    const error = validateImageFile(file);
    if (error) {
      toast.error(error);
      e.target.value = "";
      return;
    }

    const preview = URL.createObjectURL(file);
    onSelect(file, preview);
  }

  return (
    <div className="flex flex-col items-center gap-3">
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        disabled={uploading}
        className="group relative h-24 w-24 shrink-0 overflow-hidden rounded-full ring-4 ring-base-50 transition-opacity hover:opacity-90 disabled:opacity-70 dark:ring-base-950"
      >
        {previewUrl ? (
          <Image src={previewUrl} alt="Profile picture" fill sizes="96px" className="object-cover" />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-signal-500 text-2xl font-semibold text-white">
            {initials(fallbackName)}
          </div>
        )}
        <div className="absolute inset-0 flex items-center justify-center bg-black/0 transition-colors group-hover:bg-black/40">
          {uploading ? (
            <span className="h-5 w-5 animate-spin rounded-full border-2 border-white/40 border-t-white" />
          ) : (
            <Camera className="h-5 w-5 text-white opacity-0 transition-opacity group-hover:opacity-100" />
          )}
        </div>
      </button>
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        disabled={uploading}
        className="text-sm font-medium text-signal-600 hover:text-signal-700 dark:text-signal-400"
      >
        Change photo
      </button>
      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        onChange={handleChange}
        className="hidden"
      />
    </div>
  );
}
