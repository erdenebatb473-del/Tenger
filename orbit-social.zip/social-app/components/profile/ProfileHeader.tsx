import Image from "next/image";
import { CalendarDays } from "lucide-react";
import { formatJoinDate, initials } from "@/lib/utils";
import { Button } from "@/components/ui/Button";
import type { Profile } from "@/lib/types";

export function ProfileHeader({
  profile,
  isOwnProfile,
  onEdit,
}: {
  profile: Profile;
  isOwnProfile: boolean;
  onEdit?: () => void;
}) {
  return (
    <div className="animate-fade-in overflow-hidden rounded-xl2 border border-base-200 bg-white dark:border-base-800 dark:bg-base-900">
      <div className="h-28 bg-gradient-to-br from-signal-500 to-signal-700 md:h-36" />
      <div className="px-6 pb-6">
        <div className="-mt-12 flex items-end justify-between md:-mt-14">
          <div className="h-24 w-24 overflow-hidden rounded-full ring-4 ring-white dark:ring-base-900 md:h-28 md:w-28">
            {profile.avatar_url ? (
              <Image
                src={profile.avatar_url}
                alt={profile.display_name}
                width={112}
                height={112}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-signal-500 text-3xl font-semibold text-white">
                {initials(profile.display_name || profile.username)}
              </div>
            )}
          </div>
          {isOwnProfile && (
            <Button variant="secondary" onClick={onEdit} className="mb-1">
              Edit profile
            </Button>
          )}
        </div>

        <div className="mt-4">
          <h1 className="font-display text-xl font-semibold tracking-tight">
            {profile.display_name || profile.username}
          </h1>
          <p className="text-sm text-base-900/50 dark:text-base-100/50">@{profile.username}</p>
        </div>

        {profile.bio && (
          <p className="mt-4 whitespace-pre-wrap text-[15px] leading-relaxed text-base-900/80 dark:text-base-100/80">
            {profile.bio}
          </p>
        )}

        <div className="mt-4 flex items-center gap-1.5 text-sm text-base-900/45 dark:text-base-100/45">
          <CalendarDays className="h-3.5 w-3.5" />
          Joined {formatJoinDate(profile.created_at)}
        </div>
      </div>
    </div>
  );
}
