"use client";

import { useEffect, useState } from "react";
import { X } from "lucide-react";
import { toast } from "sonner";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/Button";
import { AvatarUpload } from "@/components/profile/AvatarUpload";
import {
  validateBio,
  validateDisplayName,
  validateUsername,
} from "@/lib/utils";
import type { Profile } from "@/lib/types";

interface EditProfileModalProps {
  profile: Profile;
  open: boolean;
  onClose: () => void;
  onSaved: (profile: Profile) => void;
}

export function EditProfileModal({ profile, open, onClose, onSaved }: EditProfileModalProps) {
  const [displayName, setDisplayName] = useState(profile.display_name);
  const [username, setUsername] = useState(profile.username);
  const [bio, setBio] = useState(profile.bio);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(profile.avatar_url);
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Reset local state whenever the modal is (re)opened for this profile
  useEffect(() => {
    if (open) {
      setDisplayName(profile.display_name);
      setUsername(profile.username);
      setBio(profile.bio);
      setAvatarPreview(profile.avatar_url);
      setAvatarFile(null);
      setErrors({});
    }
  }, [open, profile]);

  if (!open) return null;

  function handleAvatarSelect(file: File, preview: string) {
    setAvatarFile(file);
    setAvatarPreview(preview);
  }

  function handleCancel() {
    if (avatarPreview && avatarPreview.startsWith("blob:")) {
      URL.revokeObjectURL(avatarPreview);
    }
    onClose();
  }

  async function handleSave() {
    const nextErrors: Record<string, string> = {};
    const usernameError = validateUsername(username);
    const nameError = validateDisplayName(displayName);
    const bioError = validateBio(bio);
    if (usernameError) nextErrors.username = usernameError;
    if (nameError) nextErrors.displayName = nameError;
    if (bioError) nextErrors.bio = bioError;

    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      return;
    }

    setSaving(true);
    const supabase = createClient();

    try {
      let avatarUrl = profile.avatar_url;

      if (avatarFile) {
        const ext = avatarFile.name.split(".").pop();
        const path = `${profile.id}/${Date.now()}.${ext}`;
        const { error: uploadError } = await supabase.storage
          .from("avatars")
          .upload(path, avatarFile, { upsert: true, contentType: avatarFile.type });

        if (uploadError) throw uploadError;

        const { data } = supabase.storage.from("avatars").getPublicUrl(path);
        avatarUrl = data.publicUrl;
      }

      const { data: updated, error: updateError } = await supabase
        .from("profiles")
        .update({
          display_name: displayName.trim(),
          username: username.trim().toLowerCase(),
          bio: bio.trim(),
          avatar_url: avatarUrl,
        })
        .eq("id", profile.id)
        .select("*")
        .single();

      if (updateError) {
        if (updateError.code === "23505") {
          setErrors({ username: "That username is already taken." });
          setSaving(false);
          return;
        }
        throw updateError;
      }

      toast.success("Profile updated");
      onSaved(updated);
    } catch (err) {
      console.error(err);
      toast.error("Something went wrong. Please try again.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-base-950/40 backdrop-blur-sm animate-fade-in md:items-center">
      <div className="max-h-[92vh] w-full max-w-md overflow-y-auto rounded-t-2xl border border-base-200 bg-base-50 p-6 shadow-xl md:rounded-xl2 md:border dark:border-base-800 dark:bg-base-900">
        <div className="mb-6 flex items-center justify-between">
          <h2 className="font-display text-lg font-semibold">Edit profile</h2>
          <button
            onClick={handleCancel}
            aria-label="Close"
            className="flex h-8 w-8 items-center justify-center rounded-full text-base-900/50 hover:bg-base-100 dark:text-base-100/50 dark:hover:bg-base-800"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mb-6">
          <AvatarUpload
            previewUrl={avatarPreview}
            fallbackName={displayName || username}
            onSelect={handleAvatarSelect}
          />
        </div>

        <div className="space-y-4">
          <Field label="Display name" error={errors.displayName}>
            <input
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              maxLength={50}
              className="input"
              placeholder="Your name"
            />
          </Field>

          <Field label="Username" error={errors.username}>
            <div className="flex items-center rounded-xl border border-base-200 bg-white px-3.5 focus-within:ring-2 focus-within:ring-signal-500 dark:border-base-800 dark:bg-base-950">
              <span className="text-sm text-base-900/40 dark:text-base-100/40">@</span>
              <input
                value={username}
                onChange={(e) => setUsername(e.target.value.toLowerCase())}
                maxLength={24}
                className="w-full bg-transparent py-2.5 pl-1 text-sm outline-none"
                placeholder="username"
              />
            </div>
          </Field>

          <Field label="Bio" error={errors.bio} hint={`${bio.length}/280`}>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              maxLength={280}
              rows={3}
              className="input resize-none"
              placeholder="Tell people a little about yourself"
            />
          </Field>
        </div>

        <div className="mt-7 flex gap-3">
          <Button variant="secondary" className="flex-1" onClick={handleCancel} disabled={saving}>
            Cancel
          </Button>
          <Button className="flex-1" onClick={handleSave} loading={saving}>
            Save changes
          </Button>
        </div>
      </div>

      <style jsx global>{`
        .input {
          width: 100%;
          border-radius: 0.75rem;
          border: 1px solid rgb(228 228 224);
          background: white;
          padding: 0.625rem 0.875rem;
          font-size: 0.875rem;
          outline: none;
        }
        .input:focus {
          box-shadow: 0 0 0 2px #3355ff;
        }
        .dark .input {
          border-color: #26262b;
          background: #0b0b0d;
          color: #f2f2f0;
        }
      `}</style>
    </div>
  );
}

function Field({
  label,
  error,
  hint,
  children,
}: {
  label: string;
  error?: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <div className="mb-1.5 flex items-center justify-between">
        <span className="text-sm font-medium text-base-900/80 dark:text-base-100/80">{label}</span>
        {hint && <span className="text-xs text-base-900/40 dark:text-base-100/40">{hint}</span>}
      </div>
      {children}
      {error && <p className="mt-1.5 text-xs text-red-500">{error}</p>}
    </label>
  );
}
