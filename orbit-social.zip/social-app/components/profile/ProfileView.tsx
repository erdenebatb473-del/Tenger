"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ProfileHeader } from "@/components/profile/ProfileHeader";
import { EditProfileModal } from "@/components/profile/EditProfileModal";
import type { Profile } from "@/lib/types";

export function ProfileView({
  initialProfile,
  isOwnProfile,
}: {
  initialProfile: Profile;
  isOwnProfile: boolean;
}) {
  const [profile, setProfile] = useState(initialProfile);
  const [editing, setEditing] = useState(false);
  const router = useRouter();

  function handleSaved(updated: Profile) {
    const usernameChanged = updated.username !== profile.username;
    setProfile(updated);
    setEditing(false);
    if (usernameChanged) {
      router.replace(`/profile/${updated.username}`);
    } else {
      router.refresh();
    }
  }

  return (
    <>
      <ProfileHeader profile={profile} isOwnProfile={isOwnProfile} onEdit={() => setEditing(true)} />
      {isOwnProfile && (
        <EditProfileModal
          profile={profile}
          open={editing}
          onClose={() => setEditing(false)}
          onSaved={handleSaved}
        />
      )}
    </>
  );
}
