"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { Compass, House, Orbit, Settings } from "lucide-react";
import { cn, initials } from "@/lib/utils";
import { ThemeToggle } from "@/components/theme/ThemeToggle";
import type { Profile } from "@/lib/types";

export function MobileTopBar({ profile }: { profile: Profile }) {
  return (
    <header className="sticky top-0 z-40 flex items-center justify-between border-b border-base-200 glass px-4 py-3 md:hidden dark:border-base-800">
      <Link href="/home" className="flex items-center gap-2">
        <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-signal-500 text-white">
          <Orbit className="h-3.5 w-3.5" strokeWidth={2.25} />
        </div>
        <span className="font-display text-base font-semibold tracking-tight">Orbit</span>
      </Link>
      <div className="flex items-center gap-2">
        <ThemeToggle />
        <Link href={`/profile/${profile.username}`}>
          {profile.avatar_url ? (
            <Image
              src={profile.avatar_url}
              alt={profile.display_name}
              width={30}
              height={30}
              className="h-[30px] w-[30px] rounded-full object-cover ring-1 ring-base-200 dark:ring-base-800"
            />
          ) : (
            <div className="flex h-[30px] w-[30px] items-center justify-center rounded-full bg-signal-500 text-[11px] font-semibold text-white">
              {initials(profile.display_name || profile.username)}
            </div>
          )}
        </Link>
      </div>
    </header>
  );
}

const links = [
  { href: "/home", label: "Home", icon: House },
  { href: "/explore", label: "Explore", icon: Compass },
  { href: "/settings", label: "Settings", icon: Settings },
];

export function MobileBottomNav({ profile }: { profile: Profile }) {
  const pathname = usePathname();

  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-base-200 glass pb-[env(safe-area-inset-bottom)] md:hidden dark:border-base-800">
      <div className="flex items-center justify-around py-2">
        {links.map(({ href, label, icon: Icon }) => {
          const active = pathname.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex flex-col items-center gap-1 rounded-xl px-4 py-1.5 text-[11px] font-medium transition-colors",
                active
                  ? "text-signal-600 dark:text-signal-400"
                  : "text-base-900/50 dark:text-base-100/50"
              )}
            >
              <Icon className="h-5 w-5" strokeWidth={active ? 2.4 : 2} />
              {label}
            </Link>
          );
        })}
        <Link
          href={`/profile/${profile.username}`}
          className={cn(
            "flex flex-col items-center gap-1 rounded-xl px-4 py-1.5 text-[11px] font-medium transition-colors",
            pathname.startsWith("/profile")
              ? "text-signal-600 dark:text-signal-400"
              : "text-base-900/50 dark:text-base-100/50"
          )}
        >
          {profile.avatar_url ? (
            <Image
              src={profile.avatar_url}
              alt=""
              width={20}
              height={20}
              className={cn(
                "h-5 w-5 rounded-full object-cover",
                pathname.startsWith("/profile") && "ring-2 ring-signal-500"
              )}
            />
          ) : (
            <div className="flex h-5 w-5 items-center justify-center rounded-full bg-signal-500 text-[8px] font-semibold text-white">
              {initials(profile.display_name || profile.username)}
            </div>
          )}
          Profile
        </Link>
      </div>
    </nav>
  );
}
