"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname, useRouter } from "next/navigation";
import { Compass, House, LogOut, Orbit, Settings, User as UserIcon } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { cn, initials } from "@/lib/utils";
import { ThemeToggle } from "@/components/theme/ThemeToggle";
import type { Profile } from "@/lib/types";

const links = [
  { href: "/home", label: "Home", icon: House },
  { href: "/explore", label: "Explore", icon: Compass },
];

export function Navbar({ profile }: { profile: Profile }) {
  const pathname = usePathname();
  const router = useRouter();

  async function handleLogout() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/login");
    router.refresh();
  }

  return (
    <header className="sticky top-0 z-40 hidden border-b border-base-200 glass md:block dark:border-base-800">
      <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-6">
        <Link href="/home" className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-signal-500 text-white">
            <Orbit className="h-4 w-4" strokeWidth={2.25} />
          </div>
          <span className="font-display text-lg font-semibold tracking-tight">Orbit</span>
        </Link>

        <nav className="flex items-center gap-1">
          {links.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-colors",
                pathname.startsWith(href)
                  ? "bg-signal-50 text-signal-600 dark:bg-signal-500/10 dark:text-signal-400"
                  : "text-base-900/60 hover:bg-base-100 hover:text-base-900 dark:text-base-100/60 dark:hover:bg-base-800 dark:hover:text-base-100"
              )}
            >
              <Icon className="h-4 w-4" />
              {label}
            </Link>
          ))}
          <Link
            href={`/profile/${profile.username}`}
            className={cn(
              "flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-colors",
              pathname.startsWith("/profile")
                ? "bg-signal-50 text-signal-600 dark:bg-signal-500/10 dark:text-signal-400"
                : "text-base-900/60 hover:bg-base-100 hover:text-base-900 dark:text-base-100/60 dark:hover:bg-base-800 dark:hover:text-base-100"
            )}
          >
            <UserIcon className="h-4 w-4" />
            Profile
          </Link>
          <Link
            href="/settings"
            className={cn(
              "flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-colors",
              pathname.startsWith("/settings")
                ? "bg-signal-50 text-signal-600 dark:bg-signal-500/10 dark:text-signal-400"
                : "text-base-900/60 hover:bg-base-100 hover:text-base-900 dark:text-base-100/60 dark:hover:bg-base-800 dark:hover:text-base-100"
            )}
          >
            <Settings className="h-4 w-4" />
            Settings
          </Link>
        </nav>

        <div className="flex items-center gap-3">
          <ThemeToggle />
          <Link href={`/profile/${profile.username}`} className="shrink-0">
            <Avatar profile={profile} />
          </Link>
          <button
            onClick={handleLogout}
            aria-label="Log out"
            className="flex h-9 w-9 items-center justify-center rounded-full border border-base-200 text-base-900/70 transition-colors hover:bg-base-100 hover:text-base-900 dark:border-base-800 dark:text-base-100/70 dark:hover:bg-base-800"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </div>
    </header>
  );
}

function Avatar({ profile }: { profile: Profile }) {
  if (profile.avatar_url) {
    return (
      <Image
        src={profile.avatar_url}
        alt={profile.display_name}
        width={34}
        height={34}
        className="h-[34px] w-[34px] rounded-full object-cover ring-1 ring-base-200 dark:ring-base-800"
      />
    );
  }
  return (
    <div className="flex h-[34px] w-[34px] items-center justify-center rounded-full bg-signal-500 text-xs font-semibold text-white">
      {initials(profile.display_name || profile.username)}
    </div>
  );
}
