import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function initials(name: string) {
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");
}

const USERNAME_RE = /^[a-z0-9_]{3,24}$/;

export function validateUsername(value: string): string | null {
  const v = value.trim().toLowerCase();
  if (!v) return "Username is required.";
  if (!USERNAME_RE.test(v)) {
    return "3–24 characters: lowercase letters, numbers, and underscores only.";
  }
  return null;
}

export function validateDisplayName(value: string): string | null {
  if (!value.trim()) return "Display name is required.";
  if (value.length > 50) return "Display name must be 50 characters or fewer.";
  return null;
}

export function validateBio(value: string): string | null {
  if (value.length > 280) return "Bio must be 280 characters or fewer.";
  return null;
}

const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];
const MAX_IMAGE_BYTES = 5 * 1024 * 1024; // 5MB

export function validateImageFile(file: File): string | null {
  if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
    return "Please upload a JPG, PNG, or WEBP image.";
  }
  if (file.size > MAX_IMAGE_BYTES) {
    return "Image must be smaller than 5MB.";
  }
  return null;
}

export function formatJoinDate(iso: string) {
  return new Date(iso).toLocaleDateString("en-US", {
    month: "long",
    year: "numeric",
  });
}
