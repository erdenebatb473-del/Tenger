# Orbit — modern social profile platform

Next.js 14 (App Router) + TypeScript + Tailwind CSS + Supabase (Auth, Postgres, Storage).

Sign in with Google, get a public profile with a unique username, upload an
avatar, edit your bio, and discover other people on the platform.

---

## 1. Prerequisites

- Node.js 18.18+ and npm
- A free [Supabase](https://supabase.com) project
- A Google Cloud project (for OAuth credentials)

---

## 2. Create your Supabase project

1. Go to [supabase.com](https://supabase.com) → **New project**.
2. Once it's provisioned, open **SQL Editor** and run the two files in this
   repo, **in order**:
   1. `supabase/schema.sql` — creates the `profiles` table, indexes,
      row-level security policies, and a trigger that auto-creates a profile
      row (with a unique username) the moment someone signs in for the first
      time.
   2. `supabase/storage.sql` — creates the public `avatars` storage bucket
      and its access policies (only the owner of a folder can upload/update/
      delete inside it; anyone can view).

That's your whole backend — no separate server needed.

---

## 3. Set up Google OAuth

### 3a. Create OAuth credentials in Google Cloud

1. Open [Google Cloud Console](https://console.cloud.google.com/apis/credentials).
2. Create a project (or pick an existing one).
3. **APIs & Services → OAuth consent screen** — configure it (External is
   fine for testing), add your email as a test user if it's still in
   "Testing" mode.
4. **APIs & Services → Credentials → Create Credentials → OAuth client ID**.
   - Application type: **Web application**
   - Authorized redirect URIs — add your Supabase callback URL:
     ```
     https://<your-project-ref>.supabase.co/auth/v1/callback
     ```
     (Find your project ref in Supabase → Settings → API.)
5. Copy the generated **Client ID** and **Client Secret**.

### 3b. Enable Google in Supabase

1. In your Supabase project: **Authentication → Providers → Google**.
2. Toggle it on, paste in the **Client ID** and **Client Secret** from above.
3. Save.

### 3c. Set your site URL

In **Authentication → URL Configuration**:

- **Site URL**: `http://localhost:3000` while developing (change to your
  production domain when you deploy).
- **Redirect URLs**: add `http://localhost:3000/auth/callback` (and your
  production equivalent, e.g. `https://yourapp.com/auth/callback`).

---

## 4. Configure environment variables

```bash
cp .env.example .env.local
```

Fill in `.env.local` with values from Supabase → **Settings → API**:

```
NEXT_PUBLIC_SUPABASE_URL=https://your-project-ref.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-public-key
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

---

## 5. Install and run

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000). You'll land on the
login page — click **Continue with Google**. On first login, a profile row
is created for you automatically with a username derived from your email
(e.g. `jane.doe@gmail.com` → `@janedoe`), which you can change any time from
**Edit profile**.

---

## 6. How it's put together

```
app/
  login/                Login page (Google OAuth button)
  auth/callback/         Route handler that exchanges the OAuth code for a session
  (app)/                 Authenticated section (protected by middleware)
    layout.tsx            Fetches the current profile, renders nav
    home/                 Dashboard: your profile card + suggested profiles
    explore/               Search & discover other users
    profile/[username]/    Public profile page (yours or someone else's)
    settings/              Account info + logout
components/
  nav/                   Desktop navbar + mobile top bar/bottom nav
  profile/               Profile header, edit modal, avatar upload
  explore/               Search bar, user cards
  theme/                 Light/dark theme provider + toggle
  ui/                    Button, skeleton loaders
lib/
  supabase/              Browser, server, and middleware Supabase clients
  types.ts               Profile + typed Supabase schema
  utils.ts                Validation helpers (username, bio, image files)
middleware.ts            Refreshes the session, protects routes, redirects
supabase/
  schema.sql             Table, RLS policies, auto-profile trigger
  storage.sql             Avatars bucket + storage RLS policies
```

**Security model**: Postgres Row Level Security enforces that a user can
only insert/update/delete their *own* profile row — this is checked at the
database level, not just in the UI, so it holds even if someone calls the
API directly. Storage policies mirror this: avatar files live at
`avatars/<user_id>/...`, and the policy only allows a user to write inside
their own folder. Profiles themselves are readable by everyone, since this
is a public directory.

---

## 7. Deploying

Any Next.js host works (Vercel is the simplest). Set the same three
environment variables in your host's dashboard, and update:

- Supabase → **Authentication → URL Configuration** — add your production
  domain to Site URL and Redirect URLs.
- Google Cloud OAuth client — no change needed (the redirect URI points at
  Supabase, not your app, so it stays the same).

---

## 8. Notes

- Usernames are lowercase `a–z 0–9 _`, 3–24 characters, and enforced unique
  by a database constraint (with a friendly error if taken).
- Avatars accept JPG/PNG/WEBP up to 5MB — validated both client-side and by
  a storage bucket policy.
- Bios are capped at 280 characters.
