-- ORBIT SOCIAL — database schema
-- Run this in the Supabase SQL Editor (Project -> SQL Editor -> New query).

-- Extensions we rely on
create extension if not exists "pgcrypto";

-- =========================================================
-- 1. PROFILES TABLE
-- =========================================================
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  email text not null unique,
  username text not null unique,
  display_name text not null default '',
  avatar_url text,
  bio text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint username_length check (char_length(username) between 3 and 24),
  constraint username_format check (username ~ '^[a-z0-9_]+$'),
  constraint bio_length check (char_length(bio) <= 280),
  constraint display_name_length check (char_length(display_name) <= 50)
);

comment on table public.profiles is 'Public profile data for each authenticated user.';

-- Fast username lookup for profile pages, fast search on explore page
create unique index if not exists profiles_username_idx on public.profiles (username);
create index if not exists profiles_display_name_idx on public.profiles using gin (to_tsvector('simple', display_name));
create index if not exists profiles_username_trgm_idx on public.profiles (lower(username) text_pattern_ops);
create index if not exists profiles_created_at_idx on public.profiles (created_at desc);

-- =========================================================
-- 2. updated_at trigger
-- =========================================================
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at
  before update on public.profiles
  for each row execute procedure public.set_updated_at();

-- =========================================================
-- 3. Auto-create a profile row whenever a new auth user signs up
--    (e.g. right after their first "Continue with Google")
-- =========================================================
create or replace function public.generate_username_from_email(raw_email text)
returns text
language plpgsql
as $$
declare
  base text;
  candidate text;
  suffix int := 0;
begin
  base := lower(regexp_replace(split_part(raw_email, '@', 1), '[^a-z0-9_]', '', 'g'));
  if base = '' or base is null then
    base := 'user';
  end if;
  base := left(base, 18);
  candidate := base;

  while exists (select 1 from public.profiles p where p.username = candidate) loop
    suffix := suffix + 1;
    candidate := left(base, 18) || suffix::text;
  end loop;

  return candidate;
end;
$$;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, email, username, display_name, avatar_url)
  values (
    new.id,
    new.email,
    public.generate_username_from_email(coalesce(new.email, 'user')),
    coalesce(new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name', split_part(coalesce(new.email, 'New User'), '@', 1)),
    new.raw_user_meta_data ->> 'avatar_url'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- =========================================================
-- 4. ROW LEVEL SECURITY
-- =========================================================
alter table public.profiles enable row level security;

-- Anyone (including signed-out visitors) can read profiles — this is a
-- public social directory, not private data.
drop policy if exists "Profiles are viewable by everyone" on public.profiles;
create policy "Profiles are viewable by everyone"
  on public.profiles for select
  using (true);

-- A user can only insert the row that matches their own auth id
-- (the trigger above normally does this, but this covers manual inserts too).
drop policy if exists "Users can insert their own profile" on public.profiles;
create policy "Users can insert their own profile"
  on public.profiles for insert
  with check (auth.uid() = id);

-- A user can only update their own profile — never someone else's.
drop policy if exists "Users can update their own profile" on public.profiles;
create policy "Users can update their own profile"
  on public.profiles for update
  using (auth.uid() = id)
  with check (auth.uid() = id);

-- A user can only delete their own profile.
drop policy if exists "Users can delete their own profile" on public.profiles;
create policy "Users can delete their own profile"
  on public.profiles for delete
  using (auth.uid() = id);
