import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["var(--font-body)", "sans-serif"],
        display: ["var(--font-display)", "sans-serif"],
      },
      colors: {
        base: {
          50: "#FAFAF9",
          100: "#F2F2F0",
          200: "#E4E4E0",
          300: "#C9C9C3",
          800: "#26262B",
          900: "#16161A",
          950: "#0B0B0D",
        },
        signal: {
          50: "#EEF0FF",
          100: "#DCE0FF",
          400: "#5C6BFF",
          500: "#3355FF",
          600: "#2340E6",
          700: "#1B32B8",
        },
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      keyframes: {
        "fade-in": {
          "0%": { opacity: "0", transform: "translateY(4px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-400px 0" },
          "100%": { backgroundPosition: "400px 0" },
        },
      },
      animation: {
        "fade-in": "fade-in 0.35s ease-out",
        shimmer: "shimmer 1.6s linear infinite",
      },
    },
  },
  plugins: [],
};
export default config;
