"use client";

import { Suspense, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Orbit } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { ThemeToggle } from "@/components/theme/ThemeToggle";

export default function LoginPage() {
  return (
    <Suspense fallback={null}>
      <LoginContent />
    </Suspense>
  );
}

function LoginContent() {
  const [loading, setLoading] = useState(false);
  const searchParams = useSearchParams();
  const redirectTo = searchParams.get("redirectTo") ?? "/home";

  async function signInWithGoogle() {
    setLoading(true);
    const supabase = createClient();
    const site = process.env.NEXT_PUBLIC_SITE_URL ?? window.location.origin;

    await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: `${site}/auth/callback?redirectTo=${encodeURIComponent(redirectTo)}`,
      },
    });
  }

  return (
    <main className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-base-50 px-6 dark:bg-base-950">
      <div className="pointer-events-none absolute inset-0 [background:radial-gradient(600px_circle_at_50%_-10%,rgba(51,85,255,0.12),transparent_60%)]" />

      <div className="absolute right-6 top-6">
        <ThemeToggle />
      </div>

      <div className="relative w-full max-w-sm animate-fade-in">
        <div className="mb-8 flex flex-col items-center gap-3 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-signal-500 text-white">
            <Orbit className="h-6 w-6" strokeWidth={2.25} />
          </div>
          <h1 className="font-display text-2xl font-semibold tracking-tight">Orbit</h1>
          <p className="max-w-[26ch] text-sm text-base-900/60 dark:text-base-100/60">
            Your space, connected. Build a profile and find people worth following.
          </p>
        </div>

        <div className="rounded-xl2 border border-base-200 bg-white p-6 shadow-[0_1px_2px_rgba(16,16,20,0.04)] dark:border-base-800 dark:bg-base-900">
          <button
            onClick={signInWithGoogle}
            disabled={loading}
            className="flex w-full items-center justify-center gap-3 rounded-full border border-base-200 bg-white px-5 py-3 text-sm font-medium text-base-900 transition-colors hover:bg-base-50 disabled:opacity-60 dark:border-base-800 dark:bg-base-950 dark:text-base-100 dark:hover:bg-base-900"
          >
            {loading ? (
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-base-300 border-t-signal-500" />
            ) : (
              <GoogleMark />
            )}
            {loading ? "Connecting…" : "Continue with Google"}
          </button>
          <p className="mt-4 text-center text-xs text-base-900/50 dark:text-base-100/50">
            By continuing you agree to Orbit&apos;s Terms and acknowledge the Privacy Policy.
          </p>
        </div>
      </div>
    </main>
  );
}

function GoogleMark() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" aria-hidden="true">
      <path
        fill="#4285F4"
        d="M17.64 9.2c0-.64-.06-1.25-.16-1.84H9v3.48h4.84a4.14 4.14 0 0 1-1.8 2.72v2.26h2.9c1.7-1.56 2.7-3.87 2.7-6.62Z"
      />
      <path
        fill="#34A853"
        d="M9 18c2.43 0 4.47-.8 5.96-2.18l-2.9-2.26c-.8.54-1.84.86-3.06.86-2.35 0-4.34-1.59-5.05-3.72H.96v2.33A9 9 0 0 0 9 18Z"
      />
      <path
        fill="#FBBC05"
        d="M3.95 10.7A5.4 5.4 0 0 1 3.67 9c0-.59.1-1.16.28-1.7V4.97H.96A9 9 0 0 0 0 9c0 1.45.35 2.83.96 4.03l2.99-2.33Z"
      />
      <path
        fill="#EA4335"
        d="M9 3.58c1.32 0 2.51.46 3.44 1.35l2.58-2.58C13.46.89 11.43 0 9 0A9 9 0 0 0 .96 4.97l2.99 2.33C4.66 5.17 6.65 3.58 9 3.58Z"
      />
    </svg>
  );
}
