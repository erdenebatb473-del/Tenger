import { createClient } from "@/lib/supabase/server";
import { formatJoinDate } from "@/lib/utils";
import { SettingsActions } from "@/components/settings/SettingsActions";

export default async function SettingsPage() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user!.id)
    .single();

  if (!profile) return null;

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div className="animate-fade-in">
        <h1 className="font-display text-2xl font-semibold tracking-tight">Settings</h1>
        <p className="mt-1 text-sm text-base-900/55 dark:text-base-100/55">
          Manage your account.
        </p>
      </div>

      <div className="animate-fade-in rounded-xl2 border border-base-200 bg-white dark:border-base-800 dark:bg-base-900">
        <Row label="Email" value={profile.email} />
        <Row label="Username" value={`@${profile.username}`} />
        <Row label="Member since" value={formatJoinDate(profile.created_at)} last />
      </div>

      <SettingsActions username={profile.username} />
    </div>
  );
}

function Row({ label, value, last }: { label: string; value: string; last?: boolean }) {
  return (
    <div
      className={`flex items-center justify-between px-5 py-4 ${
        !last ? "border-b border-base-200 dark:border-base-800" : ""
      }`}
    >
      <span className="text-sm text-base-900/55 dark:text-base-100/55">{label}</span>
      <span className="text-sm font-medium">{value}</span>
    </div>
  );
}
