import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { Navbar } from "@/components/nav/Navbar";
import { MobileTopBar, MobileBottomNav } from "@/components/nav/MobileNav";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single();

  if (!profile) redirect("/login");

  return (
    <div className="min-h-screen">
      <Navbar profile={profile} />
      <MobileTopBar profile={profile} />
      <main className="mx-auto max-w-5xl px-4 pb-24 pt-6 md:px-6 md:pb-16 md:pt-8">
        {children}
      </main>
      <MobileBottomNav profile={profile} />
    </div>
  );
}
