import Link from "next/link";
import { Sparkles, UsersRound } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { ProfileCard } from "@/components/profile/ProfileCard";
import { UserCard } from "@/components/explore/UserCard";

export default async function HomePage() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user!.id)
    .single();

  const { data: suggested } = await supabase
    .from("profiles")
    .select("*")
    .neq("id", user!.id)
    .order("created_at", { ascending: false })
    .limit(6);

  if (!profile) return null;

  return (
    <div className="mx-auto max-w-3xl space-y-8">
      <div className="animate-fade-in">
        <h1 className="font-display text-2xl font-semibold tracking-tight">
          Welcome back, {profile.display_name?.split(" ")[0] || profile.username}
        </h1>
        <p className="mt-1 text-sm text-base-900/55 dark:text-base-100/55">
          Here&apos;s what&apos;s happening with your Orbit.
        </p>
      </div>

      <ProfileCard initialProfile={profile} />

      <div>
        <div className="mb-4 flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-signal-500" />
          <h2 className="font-display text-lg font-semibold tracking-tight">Suggested profiles</h2>
        </div>

        {suggested && suggested.length > 0 ? (
          <div className="grid animate-fade-in grid-cols-1 gap-4 sm:grid-cols-2">
            {suggested.map((p) => (
              <UserCard key={p.id} profile={p} />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center rounded-xl2 border border-dashed border-base-200 py-16 text-center dark:border-base-800">
            <UsersRound className="mb-3 h-7 w-7 text-base-900/30 dark:text-base-100/30" />
            <h3 className="font-display text-base font-semibold">No one else here yet</h3>
            <p className="mt-1 max-w-[32ch] text-sm text-base-900/50 dark:text-base-100/50">
              Once other people join Orbit, they&apos;ll show up here.
            </p>
          </div>
        )}

        <div className="mt-4 text-center">
          <Link
            href="/explore"
            className="text-sm font-medium text-signal-600 hover:text-signal-700 dark:text-signal-400"
          >
            Explore all profiles →
          </Link>
        </div>
      </div>
    </div>
  );
}
