"use client";

import { useEffect, useState } from "react";
import { Users } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { SearchBar } from "@/components/explore/SearchBar";
import { UserCard } from "@/components/explore/UserCard";
import { UserCardSkeleton } from "@/components/ui/Skeleton";
import type { Profile } from "@/lib/types";

export default function ExplorePage() {
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => setDebounced(query.trim()), 300);
    return () => clearTimeout(t);
  }, [query]);

  useEffect(() => {
    let active = true;
    setLoading(true);

    async function run() {
      const supabase = createClient();
      let request = supabase
        .from("profiles")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(48);

      if (debounced) {
        request = request.or(
          `username.ilike.%${debounced}%,display_name.ilike.%${debounced}%`
        );
      }

      const { data } = await request;
      if (active) {
        setProfiles(data ?? []);
        setLoading(false);
      }
    }

    run();
    return () => {
      active = false;
    };
  }, [debounced]);

  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-6 animate-fade-in">
        <h1 className="font-display text-2xl font-semibold tracking-tight">Explore</h1>
        <p className="mt-1 text-sm text-base-900/55 dark:text-base-100/55">
          Discover people on Orbit.
        </p>
      </div>

      <div className="mb-6">
        <SearchBar value={query} onChange={setQuery} />
      </div>

      {loading ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <UserCardSkeleton key={i} />
          ))}
        </div>
      ) : profiles.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-xl2 border border-dashed border-base-200 py-24 text-center dark:border-base-800">
          <Users className="mb-3 h-8 w-8 text-base-900/30 dark:text-base-100/30" />
          <h2 className="font-display text-lg font-semibold">No one found</h2>
          <p className="mt-1 text-sm text-base-900/50 dark:text-base-100/50">
            Try a different name or username.
          </p>
        </div>
      ) : (
        <div className="grid animate-fade-in grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {profiles.map((profile) => (
            <UserCard key={profile.id} profile={profile} />
          ))}
        </div>
      )}
    </div>
  );
}
