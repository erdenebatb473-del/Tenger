import { createClient } from "@/lib/supabase/server";
import { ProfileView } from "@/components/profile/ProfileView";
import { UserX } from "lucide-react";

export default async function ProfilePage({ params }: { params: { username: string } }) {
  const supabase = createClient();

  const [{ data: profile }, { data: auth }] = await Promise.all([
    supabase.from("profiles").select("*").eq("username", params.username.toLowerCase()).single(),
    supabase.auth.getUser(),
  ]);

  if (!profile) {
    return (
      <div className="flex flex-col items-center justify-center rounded-xl2 border border-dashed border-base-200 py-24 text-center dark:border-base-800">
        <UserX className="mb-3 h-8 w-8 text-base-900/30 dark:text-base-100/30" />
        <h2 className="font-display text-lg font-semibold">User not found</h2>
        <p className="mt-1 text-sm text-base-900/50 dark:text-base-100/50">
          @{params.username} doesn&apos;t exist on Orbit.
        </p>
      </div>
    );
  }

  const isOwnProfile = auth.user?.id === profile.id;

  return (
    <div className="mx-auto max-w-2xl">
      <ProfileView initialProfile={profile} isOwnProfile={isOwnProfile} />
    </div>
  );
}
