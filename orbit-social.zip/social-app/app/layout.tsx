import type { Metadata } from "next";
import { Inter, Space_Grotesk } from "next/font/google";
import { Toaster } from "sonner";
import { ThemeProvider } from "@/components/theme/ThemeProvider";
import "./globals.css";

const body = Inter({ subsets: ["latin"], variable: "--font-body", display: "swap" });
const display = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-display",
  display: "swap",
  weight: ["500", "600", "700"],
});

export const metadata: Metadata = {
  title: "Orbit — your space, connected",
  description: "A modern profile and discovery platform.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${body.variable} ${display.variable} font-sans`}>
        <ThemeProvider>
          {children}
          <Toaster
            position="bottom-center"
            toastOptions={{
              className:
                "!bg-base-900 !text-base-50 !border-none !rounded-xl dark:!bg-base-100 dark:!text-base-900",
            }}
          />
        </ThemeProvider>
      </body>
    </html>
  );
}
