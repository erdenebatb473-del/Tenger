import Link from "next/link";
import { Compass } from "lucide-react";

export default function NotFound() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-3 bg-base-50 px-6 text-center dark:bg-base-950">
      <Compass className="h-8 w-8 text-base-900/30 dark:text-base-100/30" />
      <h1 className="font-display text-xl font-semibold">Page not found</h1>
      <p className="max-w-[32ch] text-sm text-base-900/55 dark:text-base-100/55">
        The page you&apos;re looking for doesn&apos;t exist.
      </p>
      <Link href="/" className="mt-2 text-sm font-medium text-signal-600 dark:text-signal-400">
        Back to Orbit
      </Link>
    </main>
  );
}
